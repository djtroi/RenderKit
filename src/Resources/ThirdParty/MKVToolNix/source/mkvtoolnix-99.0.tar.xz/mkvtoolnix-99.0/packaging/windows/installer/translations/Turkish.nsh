!define LANG "Turkish"

# The next entry needs translations:
!insertmacro LANG_STRING STRING_EXT_LINKS_INTRO "If you need a GUI for mkvextract then give these projects a try:"
# The next entry needs translations:
!insertmacro LANG_STRING STRING_MFF_CONTINUE_ANYWAY "Continue with installation anyway"
# The next entry needs translations:
!insertmacro LANG_STRING STRING_MFF_MORE_INFORMATION "More information"
# The next entry needs translations:
!insertmacro LANG_STRING STRING_MFF_NOT_FOUND "Your Windows installation seems to lack Microsoft's 'Media Foundation' framework. This framework is required by MKVToolNix. Please install it and run the MKVToolNix installer again."
!insertmacro LANG_STRING STRING_REMOVE_JOB_FILES_QUESTION "GKA tarafından oluşturulan iş dosyaları da silinsin mi?"
!insertmacro LANG_STRING STRING_REMOVE_PROGRAM_QUESTION "Gerçekten $(^Name) uygulamasını ve tüm bileşenlerini kaldırmak istiyor musunuz?"
!insertmacro LANG_STRING STRING_UNINSTALLED_OK "$(^Name) başarılı olarak kaldırıldı."

# Local Variables:
# mode: nsis
# End:
